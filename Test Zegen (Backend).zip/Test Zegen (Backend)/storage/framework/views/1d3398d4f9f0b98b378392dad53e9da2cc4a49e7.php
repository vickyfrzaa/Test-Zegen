<?php $__env->startSection('content'); ?>

      <!-- Page Content -->
      <section>
      <form method="POST" action="<?php echo e(route('addDataDetail')); ?>">
      <?php echo csrf_field(); ?>
        <div class="container">
          <h2 class="pt-4 pb-2">Add Data</h2>
          <div class="card">
            <div class="card-body">
              <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Code</label>
                <input type="text" name="code" class="form-control" id="exampleFormControlInput1" placeholder="Code" />
              </div>
              <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Name</label>
                <input type="text" name="name" class="form-control" id="exampleFormControlInput1" placeholder="Name" />
              </div>
              <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Status</label>
                <select class="form-select" aria-label="Default select example" name="status">
                  <option selected>Status</option>
                  <option value="1">Active</option>
                  <option value="2">Unactive</option>
                </select>
              </div>
              <div class="d-grid gap-2 d-md-flex pt-2 justify-content-md-end">
                <button class="btn btn-outline-dark" type="submit">Submit</button>
                <a href="<?php echo e(asset('viewData')); ?>" class="btn btn-outline-dark">Back</a>
              </div>
            </div>
          </div>
        </div>
        </form>
      </section>
      <!-- End-->
    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test Vicky\resources\views/addData.blade.php ENDPATH**/ ?>
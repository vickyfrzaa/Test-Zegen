<?php $__env->startSection('content'); ?>

      <!-- Page Content -->
      <section class="data">
        <div class="container">
          <h2 class="pt-4 pb-2">Data</h2>
          <!-- Pre Order Table -->
          <div class="card">
            <div class="card-body">
                <a href="<?php echo e(asset('addData')); ?>">
                    <button type="button" class="btn btn-secondary">+ Add Data</button>
                </a>
                <table class="table table-hover">
                    <thead>
                        <tr>
                          <th scope="col">No.</th>
                          <th scope="col">Code</th>
                          <th scope="col">Name</th>
                          <th scope="col">Status</th>
                          <th></th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <th scope="row">1</th>
                            <td><?php echo e($data->code); ?></td>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e(($data->status == 1) ? 'Active' : 'Unactive'); ?></td>
                            <td>
                                <a href="<?php echo e(asset('editData')); ?>/<?php echo e($data->id); ?>"><i class="material-icons">edit</i></a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('deleteData')); ?>/<?php echo e($data->id); ?>"><i class="material-icons">delete</i></a>
                            </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
            </div>
          </div>
          <!-- #END# Basic Table -->
        </div>
      </section>
      </section>
      <!-- End-->
    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test Vicky\resources\views/viewData.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
    <link rel="stylesheet" href="<?php echo e(asset('Test Zegen/css/index.css')); ?>" />

    <title>Test</title>
  </head>
  <body>
    <div id="wrapper">
      <!-- Sidebar -->
      <div id="sidebar-wrapper">
        <ul class="sidebar-nav">
          <li class="sidebar-brand">
            <a href="<?php echo e(asset('home')); ?>">Project Test</a>
          </li>
          <li>
            <a href="<?php echo e(asset('viewData')); ?>">Data</a>
          </li>
          <li>
            <a href="#">Chart</a>
          </li>
          <li class="sidebar-brand fixed-bottom">
            <div class="btn-group">
                <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('register')): ?>
                <?php endif; ?>
                <?php else: ?>
              <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="<?php echo e(asset('Test Zegen/img/account.png')); ?>" class="rounded-circle" alt="" width="50px" height="70px" />
                <span><?php echo e(Auth::user()->name); ?></span>
              </button>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"
                            ><?php echo e(('Logout')); ?></a></li>
              </ul>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                <?php endif; ?>
            </div>
          </li>
        </ul>
      </div>
      <!-- End -->

    <?php echo $__env->yieldContent('content'); ?>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
    <script src="<?php echo e(asset('Test Zegen/js/index.js')); ?>"></script>
    <script src="https://kit.fontawesome.com/7f2ed2a5ac.js"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\Test Vicky\resources\views/layouts/master.blade.php ENDPATH**/ ?>
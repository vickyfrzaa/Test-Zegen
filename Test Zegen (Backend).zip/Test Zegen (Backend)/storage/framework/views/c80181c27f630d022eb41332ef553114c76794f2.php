<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <?php if($messageSuccess = Session::get('absenMasukSuccess')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                        <strong><?php echo e($messageSuccess); ?></strong>
                </div>
            <?php endif; ?>
            
            <?php if($messageSuccess = Session::get('absenKeluarSuccess')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                        <strong><?php echo e($messageSuccess); ?></strong>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">Information</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table table-responsive">
                        <form action="/absen" method="">
                            <?php echo e(csrf_field()); ?>

                            <tr>
                                <td>
                                    <input type="text" class="form-control" name="note" placeholder="Keterangan">
                                </td>
                                <td>
                                    <button type="submit" name="btnIn" class="btn btn-flat btn-primary">Absen Masuk</button>
                                </td>
                                <td>
                                    <button type="submit" name="btnOut" class="btn btn-flat btn-primary">Absen Pulang</button>
                                </td>
                            </tr>
                        </form>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">History</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table table-responsive teble-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Jam Masuk</th>
                                <th>Jam Pulang</th>
                                <th>Note</th>
                            </tr>
                        </thead>
                        <tbody>
                                <tr>
                                    <td>date</td>
                                    <td>timeIn</td>
                                    <td>timeOut</td>
                                    <td>Note</td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <b>
                                            <i>Tidak Ada Data!!</i>
                                        </b>
                                    </td>
                                </tr>
                        </tbody>
                    </table>
                    paginate
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test Vicky\resources\views/home.blade.php ENDPATH**/ ?>
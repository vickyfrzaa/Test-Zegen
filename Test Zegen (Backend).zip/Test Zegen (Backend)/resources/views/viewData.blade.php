@extends('layouts.master')

@section('content')

      <!-- Page Content -->
      <section class="data">
        <div class="container">
          <h2 class="pt-4 pb-2">Data</h2>
          <!-- Pre Order Table -->
          <div class="card">
            <div class="card-body">
                <a href="{{ asset('addData') }}">
                    <button type="button" class="btn btn-secondary">+ Add Data</button>
                </a>
                <table class="table table-hover">
                    <thead>
                        <tr>
                          <th scope="col">No.</th>
                          <th scope="col">Code</th>
                          <th scope="col">Name</th>
                          <th scope="col">Status</th>
                          <th></th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        @php $no = 1; @endphp
                        @foreach ($devices as $data)
                        <tr>
                          <th scope="row">1</th>
                            <td>{{ $data->code }}</td>
                            <td>{{ $data->name }}</td>
                            <td>{{ ($data->status == 1) ? 'Active' : 'Unactive' }}</td>
                            <td>
                                <a href="{{ asset('editData') }}/{{ $data->id }}"><i class="material-icons">edit</i></a>
                            </td>
                            <td>
                                <a href="{{ asset('deleteData') }}/{{ $data->id }}"><i class="material-icons">delete</i></a>
                            </td>
                                    </tr>
                                @endforeach
                      </tbody>
                  </table>
            </div>
          </div>
          <!-- #END# Basic Table -->
        </div>
      </section>
      </section>
      <!-- End-->
    </div>


    @endsection

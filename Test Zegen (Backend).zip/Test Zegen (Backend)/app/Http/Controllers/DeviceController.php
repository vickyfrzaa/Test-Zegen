<?php

namespace App\Http\Controllers;

use App\Device;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class DeviceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $viewData = DB::table('devices')
        ->paginate(5);

        return view('viewData')
        ->with('devices', $viewData);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('addData');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = new Device();

        $data->code = $request->input('code');
        $data->name = $request->input('name');
        $data->status = $request->input('status');

        $data->save();

        return redirect('viewData');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Device  $device
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $viewData = DB::table('devices')
        ->where('id',$id)
        ->get();

        return view('editData')
        ->with('devices', $viewData);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Device  $device
     * @return \Illuminate\Http\Response
     */
    public function edit(Device $device)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Device  $device
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = Device::where('id', $id)->first();

        $data->code = $request->input('code');
        $data->name = $request->input('name');
        $data->status = $request->input('status');

        $data->save();

        return redirect('viewData');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Device  $device
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::table('devices')->where('id',$id)->delete();

        return redirect('viewData');
        
    }

    public function viewData()
    {
        $viewUser = DB::table('devices')
        ->get();

        return view('viewData')
        ->with('devices', $viewUser);

    }
}
